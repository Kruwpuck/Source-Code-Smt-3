#include "header.h"

int main()
{
    List_Dosen Ld;
    List_Mahasiswa Lm;
    Ld.first = NULL;
    Ld.last = NULL;
    Lm.first = NULL;
    mainMenu(Ld, Lm);
    return 0;
}
