#include "header.h"
int main()
{
    List_Toko Lt;
    List_Customer Lc;
    Lt.first = NULL;
    Lc.first = NULL;
    Lc.last = NULL;
    Menu(Lt, Lc);
    return 0;
}

