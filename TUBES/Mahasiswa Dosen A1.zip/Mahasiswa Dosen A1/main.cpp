#include "header.h"

int main()
{
    List_Dosen Ld;
    List_Mahasiswa Lm;
    Ld.first = NULL;
    Lm.first = NULL;
    Lm.last = NULL;
    mainMenu(Ld, Lm);
    return 0;
}
