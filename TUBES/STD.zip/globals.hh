#pragma once
#include "header.h"

inline List_Relasi Lr;
inline List_Dosen Ld;
inline List_Mahasiswa Lm;
inline bool show_console_output = false;
inline std::string console_buffer;
