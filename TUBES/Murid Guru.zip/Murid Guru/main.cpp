#include "header.h"
int main()
{
    List_Guru Lg;
    List_Murid Lm;
    List_Relasi Lr;
    return 0;
}
