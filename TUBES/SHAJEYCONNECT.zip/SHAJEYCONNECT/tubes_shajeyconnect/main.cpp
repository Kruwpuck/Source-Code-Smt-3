#include "shajeyconnect.h"

using namespace std;

int main(){
    List_Dosen Ld;
    List_Mhs Lm;
    List_Relasi Lr;
    Ld.first = NULL;
    Lr.first = NULL;
    Lm.first = NULL;
    Lm.last = NULL;
    menu(Lr, Ld, Lm);
    return 0;
}
