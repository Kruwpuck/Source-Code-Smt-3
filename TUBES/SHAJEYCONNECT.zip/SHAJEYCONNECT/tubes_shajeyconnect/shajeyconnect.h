#ifndef SHAJEYCONNECT_H_INCLUDED
#define SHAJEYCONNECT_H_INCLUDED

#include <iostream>

#include <string>

using namespace std;

struct Elm_Mhs;
struct Elm_Dosen;
struct Elm_Relasi;

typedef Elm_Mhs* adr_mhs;
typedef Elm_Dosen* adr_dosen;
typedef Elm_Relasi* adr_relasi;

struct infotype_mhs {
    int NIM;
    string nama;
    float IPK;
};

struct infotype_dosen {
    string kode;
    int NIDN;
    string nama;
};

struct Elm_Mhs {
    infotype_mhs info;
    adr_mhs next_mhs;
    adr_mhs prev_mhs;
};

struct Elm_Dosen {
    infotype_dosen info;
    adr_dosen next_dosen;
};

struct Elm_Relasi {
    adr_mhs next_mhs;
    adr_dosen next_dosen;
    adr_relasi next_relasi;
    string info;
};

struct List_Mhs {
    adr_mhs first;
    adr_mhs last;
};

struct List_Relasi {
    adr_relasi first;
};

struct List_Dosen {
    adr_dosen first;
};

void insert_dosen(List_Dosen &L, adr_dosen P);
void insert_mhs(List_Mhs &L, adr_mhs P);
void insert_relasi(List_Relasi &L, adr_relasi P);
void delete_dosen(List_Dosen &L, adr_dosen &P);
void delete_Firstdosen(List_Dosen &L, adr_dosen &P);
void delete_Lastdosen(List_Dosen &L, adr_dosen &P);
void delete_Afterdosen(List_Dosen &L, adr_dosen &P);
void delete_mhs(List_Mhs &L, adr_mhs &P);
void delete_Firstmhs(List_Mhs &L, adr_mhs &P);
void delete_Lastmhs(List_Mhs &L, adr_mhs &P);
void delete_Aftermhs(List_Mhs &L, adr_mhs &P);
void delete_relasi(List_Relasi &L, adr_relasi &P);
void find_dosen(List_Dosen L, adr_dosen &P);
void find_mhs(List_Mhs L, adr_mhs &P);
void checkrelasi(List_Relasi L, adr_mhs P, adr_dosen Q, adr_relasi &R);
void show_dosen(List_Dosen L);
void show_mhs(List_Mhs L);
void show_mhs_daridosen(List_Relasi L, adr_dosen P);
void show_dosen_darimhs(List_Relasi L, adr_mhs P);
void show_All_relasidosen(List_Dosen Lp, List_Relasi Lr);
void show_All_relasimhs(List_Mhs Lc, List_Relasi Lr);
void count_mhs(List_Relasi L, adr_dosen P);
void count_dosen(List_Relasi L, adr_mhs P);
void count_dosenTanpamahasiswa(List_Relasi Lr, List_Dosen Lp);
void count_mhsTanpadosen(List_Relasi Lr, List_Mhs Lc);
void edit_dosen(List_Relasi &L, adr_dosen P, adr_mhs Q, adr_mhs R);
void edit_mhs(List_Relasi &L, adr_mhs P, adr_dosen Q, adr_dosen R);
void delete_relasimhs(List_Relasi &L, adr_mhs &P);
void delete_relasidosen(List_Relasi &L, adr_dosen &P);
void delete_Firstmhs(List_Mhs &L, adr_mhs &P);
void delete_Lastmhs(List_Mhs &L, adr_mhs &P);
void delete_Aftermhs(List_Mhs &L, adr_mhs &P);
void delete_Firstdosen(List_Dosen &L, adr_dosen &P);
void delete_Lastdosen(List_Dosen &L, adr_dosen &P);
void delete_Afterdosen(List_Dosen &L, adr_dosen &P);
bool checkNIM(List_Mhs L, int NIM);
bool checkNIDN(List_Dosen L, int NIDN);
void menu(List_Relasi &Lr, List_Dosen &Ld, List_Mhs &Lm);

#endif // SHAJEYCONNECT_H_INCLUDED
