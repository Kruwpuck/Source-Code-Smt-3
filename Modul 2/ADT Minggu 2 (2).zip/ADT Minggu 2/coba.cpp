/*#include <iostream>

using namespace std;

int main(){
    int *x;
    return 0;
}

*/
